# Build and Deploy a Modern Next 13 Website With Framer Motion & Tailwind CSS

### [Live Site](https://metaverse-sage-psi.vercel.app/)

![Chat Application](https://i.ibb.co/sbSHWH0/Thumbnail-1.png)

## Launch your development career with project-based coaching - https://www.jsmastery.pro
