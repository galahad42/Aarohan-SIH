'use client';

const World = () => (
  <section>
    World section
  </section>
);

export default World;
